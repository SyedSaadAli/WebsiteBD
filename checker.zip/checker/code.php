
<?php

$connection = mysqli_connect('localhost','root','','blood_donation');

if(isset($_POST['Submit_survey'])){

    Submit_Survey();
}

function Submit_Survey(){
  global $connection;
 
  $question_1 = $_POST['question_1'];
  $question_2 = $_POST['question_2'];
  $question_3 = $_POST['question_3'];
  $question_4 = $_POST['question_4'];
  $question_5 = $_POST['question_5'];
  $question_6 = $_POST['question_6'];
  
  $name = $_POST['name'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $age = $_POST['age'];
  $gender = $_POST['gender'];

  $query = "INSERT INTO survey_form (Blood_Group,First_Time,Medical_Condition,Excercise,Weakness,BMI,Name,Email,Phone,Age,Gender,User_ID) values 
  ('$question_1','$question_2','$question_3','$question_4','$question_5','$question_6','$name','$email','$phone','$age','$gender','1')";
  $query_run = mysqli_query($connection,$query);

  header('location:../index.php');
}
?>